# securityscorecard_api

A python SDK for interacting with the SecurityScorecard API