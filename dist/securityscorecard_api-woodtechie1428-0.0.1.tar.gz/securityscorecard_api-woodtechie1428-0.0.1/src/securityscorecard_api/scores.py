

class Scores:

    def get_score():
        return ("Your score is 100")